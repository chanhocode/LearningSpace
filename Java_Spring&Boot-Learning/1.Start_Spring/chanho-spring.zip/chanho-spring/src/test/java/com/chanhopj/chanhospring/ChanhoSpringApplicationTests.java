package com.chanhopj.chanhospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChanhoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
