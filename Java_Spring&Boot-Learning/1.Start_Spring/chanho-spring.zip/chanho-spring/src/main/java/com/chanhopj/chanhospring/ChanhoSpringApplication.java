package com.chanhopj.chanhospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChanhoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChanhoSpringApplication.class, args);
	}

}
